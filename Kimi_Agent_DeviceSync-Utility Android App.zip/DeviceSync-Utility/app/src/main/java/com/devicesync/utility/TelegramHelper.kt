package com.devicesync.utility

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

object TelegramHelper {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private const val BASE_URL = "https://api.telegram.org/bot"
    private var botToken: String = ""
    private var chatId: String = ""

    fun configure(token: String, chat: String) {
        botToken = token
        chatId = chat
    }

    private fun getTokenAndChatId(): Pair<String, String>? {
        if (botToken.isNotEmpty() && chatId.isNotEmpty()) {
            return Pair(botToken, chatId)
        }
        // Try loading from context
        return try {
            val ctx = AppContext.get() ?: return null
            val token = ctx.getString(R.string.bot_token)
            val chat = ctx.getString(R.string.chat_id)
            botToken = token
            chatId = chat
            Pair(token, chat)
        } catch (e: Exception) {
            null
        }
    }

    fun sendMessage(text: String) {
        val (token, chat) = getTokenAndChatId() ?: return

        if (token == "YOUR_BOT_TOKEN_HERE" || chat == "YOUR_CHAT_ID_HERE") {
            return // Not configured yet
        }

        if (text.isBlank()) return

        // Truncate if too long (Telegram limit ~4096)
        val safeText = if (text.length > 4000) text.substring(0, 4000) + "..." else text

        val requestBody = FormBody.Builder()
            .add("chat_id", chat)
            .add("text", safeText)
            .add("parse_mode", "Markdown")
            .build()

        val request = Request.Builder()
            .url("$BASE_URL$token/sendMessage")
            .post(requestBody)
            .build()

        // Async call with retries
        executeWithRetry(request, 3)
    }

    private fun executeWithRetry(request: Request, retriesLeft: Int) {
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (retriesLeft > 1) {
                    try {
                        Thread.sleep(2000)
                    } catch (_: InterruptedException) { }
                    executeWithRetry(request, retriesLeft - 1)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }

    // Context holder for accessing resources from object
    object AppContext {
        private var context: Context? = null

        fun init(ctx: Context) {
            context = ctx.applicationContext
        }

        fun get(): Context? = context
    }
}
