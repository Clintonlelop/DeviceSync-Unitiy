# ProGuard rules for DeviceSync-Utility
-keep class com.devicesync.utility.** { *; }
